﻿namespace EVote360.Application.DTOs.Request;

public sealed class PositionCreateRequest
{
    public string Name { get; set; } = default!;
}
