﻿using eVote360.Application.Abstractions.Services;
using EVote360.Application.Abstractions.Services;
using EVote360.Application.DTOs.Response;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace EVote360.Web.Controllers
{
    public class CuentaController : Controller
    {
        private readonly IUserService _userService;
        private readonly IUserSession _userSession;

        public CuentaController(IUserService userService, IUserSession userSession)
        {
            _userService = userService;
            _userSession = userSession;
        }

        [HttpGet]
        public IActionResult Acceder(string? returnUrl = null)
        {
            if (_userSession.HasUser())
            {
                return RedirectToAction("Index", "Home");
            }

            return View(new LoginVm { ReturnUrl = returnUrl });
        }

        [HttpPost]
        public async Task<IActionResult> Acceder(LoginVm model, CancellationToken ct)
        {
            if (!ModelState.IsValid)
                return View(model);

            var user = await _userService.ValidateUserAsync(model.UserName, model.Password, ct);
            if (user == null)
            {
                ModelState.AddModelError("", "Credenciales incorrectas.");
                return View(model);
            }

            var puedeIniciarSesion = await _userService.DirigentePuedeIniciarAsync(user, ct);
            if (!puedeIniciarSesion)
            {
                ModelState.AddModelError("", "No tiene un partido político asignado. Por favor, contacte a un administrador.");
                return View(model);
            }

            await CrearClaimsYAutenticarUsuario(user);

            if (!string.IsNullOrWhiteSpace(model.ReturnUrl))
                return Redirect(model.ReturnUrl);

            return user.Role == "Administrador"
                ? RedirectToAction("Index", "Home", new { area = "Admin" })
                : RedirectToAction("Index", "Home", new { area = "Dirigente" });
        }

        private async Task CrearClaimsYAutenticarUsuario(UserResponseDto user)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim(ClaimTypes.Role, user.Role)
            };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
        }

        [HttpPost]
        public async Task<IActionResult> Salir()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Denegado() => View();
    }

    public class LoginVm
    {
        public string UserName { get; set; } = "";
        public string Password { get; set; } = "";
        public string? ReturnUrl { get; set; }
    }
}
